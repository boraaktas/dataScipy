# dataScipy

I am planning to write a library which includes some basic data-science functions.
I am not going to write all functions from the scratch, but they will be more understandable for me to use them in other projects :)
