"""Top-level package for dataScipy"""

__author__ = """Bora Aktas"""
__email__ = "baktas19@ku.edu.tr"
__version__ = '0.0.3.4'